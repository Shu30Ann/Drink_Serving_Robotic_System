/**
 * DrinkServingMonitor - Tracks and evaluates robot drink serving performance
 * 
 * This class is responsible for monitoring how well the robot serves drinks to customers by:
 * 1. Tracking successful and failed serving attempts
 * 2. Evaluating serving quality using multiple metrics (handoff, stability, confirmation, proximity)
 * 3. Maintaining a log of all serving attempts with timestamps
 * 4. Calculating and displaying service success statistics
 * 
 * The monitor uses two methods to detect successful servings:
 * - A comprehensive method that uses multiple parameters weighted by importance
 * - A simplified method for basic use cases that only considers handoff and confirmation
 */
class DrinkServingMonitor {
    // Counter for successfully completed drink servings
    private int successfulServings;
    
    // Counter for failed drink serving attempts
    private int failedServings;
    
    // Chronological history of all serving attempts with timestamps and results
    private java.util.ArrayList<String> serviceLog;
    
    // Weight sensor simulation
    private static final double REGULAR_DRINK_WEIGHT = 0.5; // kg
    private static final double SPECIALTY_DRINK_WEIGHT = 0.8; // kg
    private static final double WEIGHT_TOLERANCE = 0.2; // kg - Increased tolerance for more reliable detection
    private double currentWeight;
    
    /**
     * Initializes a new drink serving monitoring system with zero counters
     * and an empty log to track the robot's serving performance over time.
     * Also initializes the weight tracking based on the robot's initial drink load.
     */
    public DrinkServingMonitor() {
        this.successfulServings = 0;  // Start with no successful servings
        this.failedServings = 0;      // Start with no failed servings
        this.serviceLog = new java.util.ArrayList<>();  // Create empty log for recording attempts
        
        // Initialize weight tracking with the robot's initial drink load
        // Assuming robot starts with 10 regular drinks and 3 specialty drinks
        this.currentWeight = (10 * REGULAR_DRINK_WEIGHT) + (3 * SPECIALTY_DRINK_WEIGHT);
    }
    
    /**
     * Simulates weight sensor reading for drink handoff detection
     * @param isRegularDrink - true for regular drink, false for specialty drink
     * @return true if weight change indicates successful handoff
     */
    public boolean detectWeightChange(boolean isRegularDrink) {
        double expectedWeight = isRegularDrink ? REGULAR_DRINK_WEIGHT : SPECIALTY_DRINK_WEIGHT;
        
        // Simulate weight change with some random variation
        double weightChange = expectedWeight + (Math.random() - 0.5) * WEIGHT_TOLERANCE;
        double newWeight = currentWeight - weightChange;
        
        // Check if weight change is within acceptable range
        // More lenient check - allow for some variation in the weight change
        boolean isSuccessful = Math.abs(newWeight - (currentWeight - expectedWeight)) <= WEIGHT_TOLERANCE;
        
        // Update current weight if handoff was successful
        if (isSuccessful) {
            currentWeight = newWeight;
            System.out.println("Weight change detected: " + String.format("%.2f", weightChange) + " kg");
        } else {
            System.out.println("Weight change detection failed. Expected: " + String.format("%.2f", expectedWeight) + 
                             " kg, Detected: " + String.format("%.2f", weightChange) + " kg");
        }
        
        return isSuccessful;
    }
    
    /**
     * Simulates stability sensor reading during drink serving
     * @return stability score (0-10)
     */
    public double measureStability() {
        // Simulate stability sensor with some random variation
        double baseStability = 8.5; // Increased base stability for more reliable readings
        double variation = (Math.random() - 0.5) * 1.5; // Reduced variation for more consistent results
        return Math.max(0.0, Math.min(10.0, baseStability + variation));
    }
    
    /**
     * Simulates proximity sensor reading for optimal serving position
     * @return proximity score (0-10)
     */
    public double measureProximity() {
        // Simulate proximity sensor with some random variation
        double baseProximity = 7.5; // Increased base proximity for more reliable readings
        double variation = (Math.random() - 0.5) * 1.5; // Reduced variation for more consistent results
        return Math.max(0.0, Math.min(10.0, baseProximity + variation));
    }
    
    /**
     * Comprehensive method that evaluates if a drink was served successfully
     * using multiple weighted parameters to calculate a success score.
     * 
     * The success criteria uses a weighted scoring system where:
     * - 40% of score comes from successful physical handoff (weight change)
     * - 30% from drink stability during serving (0-10 scale)
     * - 20% from weight confirmation
     * - 10% from robot's proximity to customer (0-10 scale)
     * 
     * A score of 70% or higher is considered a successful serving.
     * 
     * @param isRegularDrink - Whether this is a regular or specialty drink
     * @return true if serving was successful (score >= 70%), false otherwise
     */
    public boolean detectSuccessfulServing(boolean isRegularDrink) {
        // Start with zero score and add weighted components
        double successScore = 0;
        
        // Weight change is the most critical factor - 40% of total possible score
        boolean weightChangeDetected = detectWeightChange(isRegularDrink);
        if (weightChangeDetected) {
            successScore += 40;  // If weight change detected, add 40 points
        }
        
        // Stability measures if drink was held steady, preventing spills - 30% of score
        double stabilityScore = measureStability();
        successScore += stabilityScore * 3;
        
        // Weight confirmation provides certainty - 20% of score
        if (weightChangeDetected) {
            successScore += 20;  // If weight confirmed, add 20 points
        }
        
        // Proximity ensures robot positioned correctly for comfortable handoff - 10% of score
        double proximityScore = measureProximity();
        successScore += proximityScore;
        
        // Create timestamp for logging this serving attempt
        java.time.LocalDateTime timestamp = java.time.LocalDateTime.now();
        
        // Success threshold is 70% of possible points (70 out of 100)
        boolean isSuccess = successScore >= 70;
        
        // Create detailed log entry with timestamp, result, and numerical score
        String logEntry = timestamp + " - " + (isRegularDrink ? "Regular" : "Specialty") + 
                         " drink serving attempt: " + (isSuccess ? "SUCCESS" : "FAILED") +
                         " (Score: " + String.format("%.1f", successScore) + "%)";
        
        // Add this attempt to the historical service log
        serviceLog.add(logEntry);
        
        // Update the appropriate counter based on success/failure
        if (isSuccess) {
            successfulServings++;
        } else {
            failedServings++;
        }
        
        return isSuccess;
    }
    
    /**
     * Simplified method for basic drink serving detection
     * Only considers weight change and confirmation
     * @param isRegularDrink - Whether this is a regular or specialty drink
     * @return true if serving was successful
     */
    public boolean detectSimpleServing(boolean isRegularDrink) {
        boolean weightChangeDetected = detectWeightChange(isRegularDrink);
        boolean isSuccess = weightChangeDetected;
        
        // Create timestamp for logging this serving attempt
        java.time.LocalDateTime timestamp = java.time.LocalDateTime.now();
        
        // Create log entry
        String logEntry = timestamp + " - " + (isRegularDrink ? "Regular" : "Specialty") + 
                         " drink serving attempt: " + (isSuccess ? "SUCCESS" : "FAILED");
        
        // Add to log
        serviceLog.add(logEntry);
        
        // Update counters
        if (isSuccess) {
            successfulServings++;
        } else {
            failedServings++;
        }
        
        return isSuccess;
    }
    
    /**
     * Displays service statistics including success rate and recent attempts
     */
    public void displayServiceStatistics() {
        System.out.println("\n=== Service Statistics ===");
        int totalServings = successfulServings + failedServings;
        
        if (totalServings > 0) {
            double successRate = (double) successfulServings / totalServings * 100;
            System.out.println("Total servings attempted: " + totalServings);
            System.out.println("Successful servings: " + successfulServings);
            System.out.println("Failed servings: " + failedServings);
            System.out.println("Success rate: " + String.format("%.1f", successRate) + "%");
            
            System.out.println("\nRecent serving attempts:");
            int recentCount = Math.min(5, serviceLog.size());
            for (int i = serviceLog.size() - 1; i >= serviceLog.size() - recentCount; i--) {
                System.out.println(serviceLog.get(i));
            }
        } else {
            System.out.println("No serving attempts recorded yet.");
        }
    }
}