import java.util.Random;
public class RoomMap {
    private String[][] grid;// 2D array representing the dining area layout
    private int robotX, robotY;// Robot's current position coordinates
    private int startX, startY;// Default starting position for the robot
    private String spotName;// Name of this specific dining area

    /**
     * Sets up a new dining area map.
     * The dimensions came from actual restaurant floor plans.
     * width - How many columns the area has
     * height - How many rows the area has
     * startX - Robot's default column position
     * startY - Robot's default row position
     * spotName - Which dining area this represents
     */
    public RoomMap(int width, int height, int startX, int startY, String spotName) {
        this.grid = new String[height][width];
        this.startX = startX;
        this.startY = startY;
        this.spotName = spotName;
        placeRobot(startX, startY);// Place robot at starting position
        initializeTables();// Add tables to the layout
    }

    /**
     * Randomly places tables throughout the dining area.
     * The 30% density seemed realistic after checking several restaurants.
     * We skip the robot's starting position to avoid blocking it.
     */
    private void initializeTables() {
        // Add random tables (T) to the map
        Random rand = new Random();
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                // 30% chance for a table, but never on robot's start spot
                if (rand.nextDouble() < 0.3 && !(i == startY && j == startX)) {
                    grid[i][j] = "T"; // T represents a table
                }
            }
        }
    }
     /**
     * Moves the robot to new coordinates.
     * Clears the old position first to avoid duplicate markers.
     * x - Column to move to
     * y - Row to move to
     */
    public void placeRobot(int x, int y) {
        // Clear previous position if valid
        if (robotX >= 0 && robotY >= 0) grid[robotY][robotX] = null;
        robotX = x;
        robotY = y;
        grid[y][x] = "R"; // R represents robot
    }
    /**
     * Shows the current map layout.
     * Uses simple brackets for readability.
     * Empty spots show as [ ], tables as [T], robot as [R].
     */
    public void displayMap() {
        System.out.println("\n=== " + spotName + " Map ===");
        for (String[] row : grid) {
            for (String cell : row) {
                System.out.print(cell == null ? "[ ]" : "[" + cell + "]");
            }
            System.out.println(); // New line after each row
        }
    }
    /**
     * Returns robot to its starting position.
     * Helpful for resetting between service cycles.
     */
    public void returnToStart() {
        placeRobot(startX, startY);
        System.out.println("\nRobot returned to original position");
        displayMap();
    }

    // Getters for robot position
    public int getRobotX() { return robotX; }
    public int getRobotY() { return robotY; }
    
    // Getters for grid dimensions
    public int getGridWidth() { return grid[0].length; }
    public int getGridHeight() { return grid.length; }

    /**
     * Checks if a move to the given coordinates is valid
     * @param x New x coordinate
     * @param y New y coordinate
     * @return true if move is valid, false otherwise
     */
    public boolean isValidMove(int x, int y) {
        // Check if coordinates are within grid bounds
        if (x < 0 || x >= grid[0].length || y < 0 || y >= grid.length) {
            return false;
        }
        // Check if destination has a table
        return grid[y][x] != "T";
    }

    /**
     * Moves the robot in the specified direction
     * @param direction "up", "down", "left", or "right"
     * @return true if move was successful, false otherwise
     */
    public boolean moveRobot(String direction) {
        int newX = robotX;
        int newY = robotY;
        
        switch (direction.toLowerCase()) {
            case "up":
                newY--;
                break;
            case "down":
                newY++;
                break;
            case "left":
                newX--;
                break;
            case "right":
                newX++;
                break;
            default:
                return false;
        }
        
        if (isValidMove(newX, newY)) {
            placeRobot(newX, newY);
            System.out.println("Robot moved " + direction);
            displayMap();
            return true;
        } else {
            System.out.println("Cannot move " + direction + " - path is blocked or out of bounds!");
            return false;
        }
    }
}