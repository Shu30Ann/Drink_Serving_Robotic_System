/**
 * Handles all the real-time safety checks for our serving robots.
 * We developed this after watching how human servers navigate crowded spaces,
 * translating those movements into code logic.
 */
class DynamicDrinkServing {
    // Standard social distancing of 1 meter
    private static final double SAFE_DISTANCE = 1.0;
    
    // Method to check if the robot is maintaining safe distance from all directions
    public boolean checkSafeDistance(double leftDist, double rightDist, double frontDist, double backDist) {
        return leftDist >= SAFE_DISTANCE && rightDist >= SAFE_DISTANCE && 
               frontDist >= SAFE_DISTANCE && backDist >= SAFE_DISTANCE;
    }
    
    // Method to provide movement advice based on distances
    public void provideMoveAdvice(double leftDist, double rightDist, double frontDist, double backDist) {
        if (leftDist < SAFE_DISTANCE) {
            double moveDistance = SAFE_DISTANCE - leftDist;
            System.out.println("WARNING: Too close on the left side!");
            System.out.println("Please move right by " + String.format("%.2f", moveDistance) + " meters.");
        }
        
        if (rightDist < SAFE_DISTANCE) {
            double moveDistance = SAFE_DISTANCE - rightDist;
            System.out.println("WARNING: Too close on the right side!");
            System.out.println("Please move left by " + String.format("%.2f", moveDistance) + " meters.");
        }
        
        if (frontDist < SAFE_DISTANCE) {
            double moveDistance = SAFE_DISTANCE - frontDist;
            System.out.println("WARNING: Too close in front!");
            System.out.println("Please move back by " + String.format("%.2f", moveDistance) + " meters.");
        }
        
        if (backDist < SAFE_DISTANCE) {
            double moveDistance = SAFE_DISTANCE - backDist;
            System.out.println("WARNING: Too close behind!");
            System.out.println("Please move forward by " + String.format("%.2f", moveDistance) + " meters.");
        }
    }
    
    // Method to determine contact status based on distances
    public String determineContactStatus(double leftDist, double rightDist, double frontDist, double backDist) {
        // If any distance is less than safe distance, it's a casual contact
        if (leftDist < SAFE_DISTANCE || rightDist < SAFE_DISTANCE || 
            frontDist < SAFE_DISTANCE || backDist < SAFE_DISTANCE) {
            return "Casual Contact";
        } else {
            return "Safe Distance";
        }
    }
    
    // Additional feature: Calculate crowding level of the spot
    public String calculateCrowdingLevel(int currentOccupancy, int maxCapacity) {
        double occupancyPercentage = (double) currentOccupancy / maxCapacity * 100;
        
        if (occupancyPercentage < 30) {
            return "Low";
        } else if (occupancyPercentage < 70) {
            return "Moderate";
        } else {
            return "High";
        }
    }
    
    // Additional feature: Recommend optimal serving path based on crowding
    public String recommendServingPath(String crowdingLevel) {
        switch (crowdingLevel) {
            case "Low":
                return "Direct path - serve drinks in any order";
            case "Moderate":
                return "Clockwise path - start from the entrance and move clockwise";
            case "High":
                return "Zigzag path - alternate between tables to avoid congestion";
            default:
                return "No recommendation available";
        }
    }
    
    // Additional feature: Estimate collision risk based on crowding and distances
    public double estimateCollisionRisk(String crowdingLevel, double minDistance) {
        double baseRisk = 0.0;
        
        // Risk based on crowding level
        switch (crowdingLevel) {
            case "Low":
                baseRisk = 0.1;
                break;
            case "Moderate":
                baseRisk = 0.3;
                break;
            case "High":
                baseRisk = 0.6;
                break;
            default:
                baseRisk = 0.2;
        }
        
        // Risk multiplier based on minimum distance
        double distanceMultiplier = SAFE_DISTANCE / Math.max(minDistance, 0.1);
        
        // Calculate final risk percentage (capped at 100%)
        return Math.min(baseRisk * distanceMultiplier * 100, 100.0);
    }
}