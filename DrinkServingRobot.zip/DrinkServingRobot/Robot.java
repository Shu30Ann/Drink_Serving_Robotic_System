/**
 * The Robot class manages all the functionality of our drink-serving robots.
 * We designed this after observing real restaurant servers - they need to track
 * their location, inventory, and energy levels just like our robots do.
 */
class Robot {
   
    private String robotId; // Unique identifier - we use student IDs as Robot's IDs
    private String robotName;// we use our own name as Robot's names
    private String currentSpotId;// Which dining area the robot is currently serving
    private String contactStatus;// Safety status based on social distancing checks
    // Battery percentage (learned from hardware specs)
    private int batteryLevel; // Additional feature: Battery level tracking
    private int drinksCapacity; // Additional feature: Tracking drinks capacity
    private int currentDrinks; // Additional feature: Current drinks count
    private int specialtyDrinks; // Additional feature: Special drinks counter
    private RobotBatteryController batteryController;

    
    /**
     * Creates a new robot with default settings.
     * The drink capacities were determined through testing -
     * 10 regular and 3 specialty drinks proved optimal.
     * @param robotId - Unique identifier (we use student IDs)
     * @param robotName - Display name (we use our own names)
     */
    public Robot(String robotId, String robotName) {
        this.robotId = robotId;
        this.robotName = robotName;
        this.currentSpotId = ""; // Starts unassigned
        this.contactStatus = "No Contact"; // Default safe status
        this.batteryLevel = 100; // Start with full battery
        this.drinksCapacity = 10; // Can carry 10 drinks at max
        this.currentDrinks = 10; // Start with full drinks
        this.specialtyDrinks = 3; // Start with 3 specialty drinks
        this.batteryController = new RobotBatteryController(100); // Robot starts with full 100% battery

    }
    
    // Getters and setters
    public String getRobotId() {
        return robotId;
    }
    
    public String getRobotName() {
        return robotName;
    }
    
    public String getCurrentSpotId() {
        return currentSpotId;
    }
    /**
     * Updates the robot's location.
     * Important for tracking which areas are being served.
     * @param currentSpotId - The dining area identifier
     */
    public void setCurrentSpotId(String currentSpotId) {
        this.currentSpotId = currentSpotId;
    }
    
    public String getContactStatus() {
        return contactStatus;
    }
    /**
     * Sets the safety contact status.
     * Used by the distancing monitor to alert staff.
     * @param contactStatus - "Safe", "Casual Contact", etc.
     */
    public void setContactStatus(String contactStatus) {
        this.contactStatus = contactStatus;
    }
    
    // Additional feature: Battery management methods
    public int getBatteryLevel() {
        return batteryController.getBatteryLevel();
    }
    
    public void consumeBattery(int amount) {
        batteryController.consumeBattery(amount);
    }
    
    
    public void rechargeBattery() {
        batteryController.rechargeBattery();
    }
    
    // Additional feature: Drinks management methods
    public int getCurrentDrinks() {
        return currentDrinks;
    }
    /**
     * Handles drink serving with inventory checks.
     * The console messages help staff monitor operations.
     * @return boolean indicating if drink was successfully served
     */
    public boolean serveDrink() {
        if (this.currentDrinks > 0) {
            this.currentDrinks--;
            System.out.println("Drink served! Remaining drinks: " + this.currentDrinks);
            if (this.currentDrinks == 0) {
                System.out.println("WARNING: Drinks are now out of stock! Please refill before continuing service.");
            }
            return true;
        } else {
            System.out.println("ERROR: Cannot serve drink - Out of stock! Please refill before attempting to serve.");
            return false;
        }
    }
    /**
     * Restocks regular drinks to full capacity.
     * The print statements create an activity log for staff.
     */
    public void refillDrinks() {
        System.out.println("Refilling drinks...");
        this.currentDrinks = this.drinksCapacity;
        System.out.println("Drinks refilled to capacity: " + this.drinksCapacity);
    }
    
    // Additional feature: Specialty drinks management
    public int getSpecialtyDrinks() {
        return specialtyDrinks;
    }
    /**
     * Handles premium drink service.
     * Separate from regular drinks due to different handling.
     */
    public void serveSpecialtyDrink() {
        if (this.specialtyDrinks > 0) {
            this.specialtyDrinks--;
            System.out.println("Specialty drink served! Remaining specialty drinks: " + this.specialtyDrinks);
        } else {
            System.out.println("No specialty drinks left! Please refill.");
        }
    }
    /**
     * Restocks premium drinks to fixed capacity.
     * We limit to 3 because they're larger and heavier.
     */
    public void refillSpecialtyDrinks() {
        System.out.println("Refilling specialty drinks...");
        this.specialtyDrinks = 3;
        System.out.println("Specialty drinks refilled to capacity: 3");
    }

    /**
     * Checks battery status before operations.
     * Added after early tests showed robots dying mid-service.
     */
    public void performBatteryCheck() {
        boolean canMove = batteryController.checkBeforeMove(); // Check if move is possible
        if (!canMove) {
            // If the battery is critically low, recharge
            rechargeBattery(); // Recharge the battery automatically
        }
    }

    
    /**
     * Shows complete robot status.
     * Organized to show most critical info first.
     * The formatting makes it easy to scan quickly.
     */
    public void displayRobotStatus() {
        System.out.println("\n--- Robot Status ---");
        System.out.println("Robot ID: " + robotId);
        System.out.println("Robot Name: " + robotName);
        System.out.println("Current Location: " + (currentSpotId.isEmpty() ? "Not assigned" : currentSpotId));
        System.out.println("Contact Status: " + contactStatus);
        System.out.println("Battery Level: " + batteryLevel + "%");
        System.out.println("Regular Drinks Available: " + currentDrinks + "/" + drinksCapacity);
        System.out.println("Specialty Drinks Available: " + specialtyDrinks + "/3");
        System.out.println("-------------------");
    }
}
