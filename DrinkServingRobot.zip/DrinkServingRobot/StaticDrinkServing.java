/**
 * A robotic drink serving system for restaurants that handles both regular and VIP service.
 * This static version manages specific dining spots with capacity restrictions.
 */
class StaticDrinkServing extends DynamicDrinkServing {
    // System components
    private RestrictedSpots[] spots;       // All available dining areas in the restaurant
    private Robot[] robots;                // Available serving robots
    private Robot activeRobot;             // Currently selected robot for serving
    private java.util.Scanner scanner;     // For reading user input
    private java.time.LocalDateTime currentDateTime; // Tracks current date/time
    private DrinkServingMonitor serviceMonitor; // Monitors drink serving success rates
    private RoomMap currentMap;
    

    // VIP features
    private String[] vipCustomers = {"VIP1", "VIP2", "VIP3"}; // Special customers list
    private boolean isVipMode = false;    // Flag for VIP priority service mode
    
    private boolean emergencyMode = false; // New flag
    private java.util.HashMap<String, Boolean> entryPermits; // Track entry permits for each spot

    /**
     * Sets up the drink serving system with:
     * - 5 predefined dining spots
     * - 2 serving robots
     * - Monitoring system
     */
    public StaticDrinkServing() {
        // Initialize dining spots with their capacities
        this.spots = new RestrictedSpots[5];
        spots[0] = new RestrictedSpots("S001", "Dining Foyer", 60.0, 15);
        spots[1] = new RestrictedSpots("S002", "Main Dining Hall", 120.0, 30);
        spots[2] = new RestrictedSpots("S003", "Dining Room One", 40.0, 10);
        spots[3] = new RestrictedSpots("S004", "Dining Room Two", 40.0, 10);
        spots[4] = new RestrictedSpots("S005", "Family Dining Room", 80.0, 20);
        
        // Create our serving robots with our own name and Student IDs
        this.robots = new Robot[2];
        robots[0] = new Robot("20612781", "Lim Chai Shuen");
        robots[1] = new Robot("20609412", "Moo Shu Ann");
        
        // Default to first robot for initial service
        this.activeRobot = robots[0];
        
        // Set up user input and current time tracking
        scanner = new java.util.Scanner(System.in);
        currentDateTime = java.time.LocalDateTime.now();
        this.serviceMonitor = new DrinkServingMonitor();
        
        // Initialize entry permits
        this.entryPermits = new java.util.HashMap<>();
        for (RestrictedSpots spot : spots) {
            entryPermits.put(spot.getSpotId(), false);
        }
    }
    
    /**
     * Main system loop that handles:
     * - Robot selection
     * - Main menu navigation
     * - System shutdown
     */
    public void runSystem() {
        System.out.println("=== Drink Serving Robotic System ===");
        System.out.println("Welcome to the Malaysian Restaurant Robot System!");
        
        // Show available robots for selection
        System.out.println("\nAvailable Robots:");
        for (int i = 0; i < robots.length; i++) {
            Robot r = robots[i];
            System.out.println((i + 1) + ". " + r.getRobotName() + " (ID: " + r.getRobotId() + ")");
        }
        
        // Let staff select which robot to use
        System.out.print("\nSelect a robot (1-" + robots.length + "): ");
        int robotChoice = getUserChoice(1, robots.length);
        activeRobot = robots[robotChoice - 1];
        System.out.println("You selected: " + activeRobot.getRobotName());
        activeRobot.performBatteryCheck();

    

        // Keep system running until user chooses to exit
        boolean exit = false;
        while (!exit) {
            displayMainMenu();
            int choice = getUserChoice(1, 8);
            
            // Handle user's menu selection
            switch (choice) {
                case 1:
                    selectSpot();       // Choose dining area to serve drinks
                    break;
                case 2:
                    activeRobot.displayRobotStatus(); // Check robot's status
                    break;
                case 3:
                    displayAllSpots();  // View all dining area info
                    break;
                case 4:
                    toggleVipMode();    // Toggle VIP priority service
                    break;
                case 5:
                    manageDrinks();     // Handle drink inventory
                    break;
                case 6:
                    manageBattery();    // Check/charge battery
                    break;
                case 7:
                    switchRobot();      // Change active robot
                    break;
                case 8:
                    exit = true;        // Shut down system
                    System.out.println("Thank you for using the Drink Serving Robotic System. Goodbye!");
                    break;
            }
        }
        
        // Clean up resources
        scanner.close();
    }
    
    /**
     * Shows the main menu options and current active robot
     */
    private void displayMainMenu() {
        System.out.println("\n=== Main Menu ===");
        System.out.println("Active Robot: " + activeRobot.getRobotName() + " (ID: " + activeRobot.getRobotId() + ")");
        System.out.println("1. Select a spot to serve drinks");
        System.out.println("2. Display robot status");
        System.out.println("3. Display all spots information");
        System.out.println("4. Toggle VIP Mode");
        System.out.println("5. Manage drinks");
        System.out.println("6. Manage battery");
        System.out.println("7. Switch robot");
        System.out.println("8. Exit");
        System.out.print("Enter your choice (1-8): ");
    }
    
    /**
     * Allows switching between available robots
     */
    private void switchRobot() {
        System.out.println("\n=== Switch Robot ===");
        System.out.println("Available Robots:");
        
        // List all robots with their numbers
        for (int i = 0; i < robots.length; i++) {
            Robot r = robots[i];
            System.out.println((i + 1) + ". " + r.getRobotName() + " (ID: " + r.getRobotId() + ")");
        }
        
        // Get user selection and update active robot
        System.out.print("Select a robot (1-" + robots.length + "): ");
        int robotChoice = getUserChoice(1, robots.length);
        activeRobot = robots[robotChoice - 1];
        System.out.println("You switched to: " + activeRobot.getRobotName());
        activeRobot.performBatteryCheck();

    }
    
    /**
     * Gets and validates user input within a specified range
     * @param min - Minimum valid choice
     * @param max - Maximum valid choice
     * @return Validated user selection
     */
    private int getUserChoice(int min, int max) {
        int choice = -1;
        // Keep asking until we get valid input
        while (choice < min || choice > max) {
            try {
                choice = scanner.nextInt();
                scanner.nextLine(); // Clear input buffer
                if (choice < min || choice > max) {
                    System.out.print("Invalid choice. Please enter a number between " + min + " and " + max + ": ");
                }
            } catch (Exception e) {
                scanner.nextLine(); // Clear buffer on invalid input
                System.out.print("Invalid input. Please enter a number: ");
            }
        }
        return choice;
    }
    
    /**
     * Lets staff select a dining area to serve drinks in
     */
    private void selectSpot() {
        System.out.println("\n=== Available Spots ===");
        // Show all spots with current occupancy
        for (int i = 0; i < spots.length; i++) {
            System.out.println((i + 1) + ". " + spots[i].getSpotName() + 
                              " (Current Occupancy: " + spots[i].getCurrentOccupancy() + "/" + 
                              spots[i].getSpotMaximumCapacity() + ")");
        }
        
        // Get spot selection from user
        System.out.print("Select a spot (1-5): ");
        int spotIndex = getUserChoice(1, 5) - 1;
        
        // Handle full spots by offering wait option
        if (spots[spotIndex].isFull()) {
            System.out.println("\nSorry, the selected spot is full!");
            System.out.println("Average waiting time: " + spots[spotIndex].getSpotPermittedAverageTime() + " minutes");
            System.out.print("Do you want to wait? (Y/N): ");
            String answer = scanner.nextLine().trim().toUpperCase();
            
            if (answer.equals("Y")) {
                // Simulate waiting time and battery consumption
                System.out.println("Waiting for " + spots[spotIndex].getSpotPermittedAverageTime() + " minutes...");
                activeRobot.consumeBattery(spots[spotIndex].getSpotPermittedAverageTime() / 5);
                System.out.println("Wait time reached. You can now enter the spot.");
                enterSpot(spotIndex);
            } else {
                System.out.println("Returning to main menu...");
            }
        } else {
            // Proceed directly if spot isn't full
            enterSpot(spotIndex);
        }
    }
    
    /**
     * Checks if a robot has permission to enter a specific spot
     * @param spotId - The ID of the spot to check
     * @return true if entry is permitted, false otherwise
     */
    private boolean checkEntryPermit(String spotId) {
        return entryPermits.getOrDefault(spotId, false);
    }

    /**
     * Requests and processes an entry permit for a spot
     * @param spotId - The ID of the spot to request permit for
     * @return true if permit was granted, false if denied
     */
    private boolean requestEntryPermit(String spotId) {
        System.out.println("\n=== Entry Permit Request ===");
        System.out.println("Requesting entry permit for spot: " + spotId);
        
        // Check if spot is at capacity
        RestrictedSpots spot = null;
        for (RestrictedSpots s : spots) {
            if (s.getSpotId().equals(spotId)) {
                spot = s;
                break;
            }
        }
        
        if (spot == null) {
            System.out.println("ERROR: Invalid spot ID!");
            return false;
        }
        
        if (spot.isFull()) {
            System.out.println("DENIED: Spot is at maximum capacity!");
            return false;
        }
        
        // Check current occupancy against social distancing guidelines
        int currentOccupancy = spot.getCurrentOccupancy();
        int maxCapacity = spot.getSpotMaximumCapacity();
        double occupancyPercentage = (double) currentOccupancy / maxCapacity * 100;
        
        if (occupancyPercentage >= 90) {
            System.out.println("DENIED: Spot is too crowded for safe social distancing!");
            return false;
        }
        
        // Grant permit
        entryPermits.put(spotId, true);
        System.out.println("PERMIT GRANTED: Entry allowed to " + spot.getSpotName());
        return true;
    }

    /**
     * Handles the robot entering a selected dining spot
     * @param spotIndex - Index of the selected dining area
     */
    private void enterSpot(int spotIndex) {
        RestrictedSpots selectedSpot = spots[spotIndex];
        
        // Check for entry permit before proceeding
        if (!checkEntryPermit(selectedSpot.getSpotId())) {
            System.out.println("\nEntry permit required before entering " + selectedSpot.getSpotName());
            if (!requestEntryPermit(selectedSpot.getSpotId())) {
                System.out.println("Cannot enter spot without valid permit. Returning to main menu...");
                return;
            }
        }
        
        activeRobot.setCurrentSpotId(selectedSpot.getSpotId());
        
        System.out.println("\nEntering " + selectedSpot.getSpotName() + "...");
        selectedSpot.displaySpotInfo();

        // Create and display map for this spot
        int mapWidth = 10;
        int mapHeight = 6;
        currentMap = new RoomMap(mapWidth, mapHeight, 0, 0, selectedSpot.getSpotName());
        currentMap.displayMap();
        
        // Check social distancing in all directions
        System.out.println("\n=== Dynamic Distancing Check ===");
        System.out.println("Please enter the distance from people in meters:");
        
        System.out.print("Left side: ");
        double leftDist = scanner.nextDouble();
        
        System.out.print("Right side: ");
        double rightDist = scanner.nextDouble();
        
        System.out.print("Front: ");
        double frontDist = scanner.nextDouble();
        
        System.out.print("Back: ");
        double backDist = scanner.nextDouble();
        scanner.nextLine(); // Clear input buffer


        // After reading all distances
        double safeThreshold = 1.0;

        // Balance horizontal (left-right)
        double totalHorizontal = leftDist + rightDist;
        double targetHorizontal = totalHorizontal / 2.0;
        double moveRight = targetHorizontal - leftDist;
        double adjustedLeft = leftDist + moveRight;
        double adjustedRight = rightDist - moveRight;

        // Balance vertical (front-back)
        double totalVertical = frontDist + backDist;
        double targetVertical = totalVertical / 2.0;
        double moveBack = targetVertical - frontDist;
        double adjustedFront = frontDist + moveBack;
        double adjustedBack = backDist - moveBack;

        // After balancing movement, calculate minimum new distance
        double minAdjustedDistance = Math.min(Math.min(adjustedLeft, adjustedRight), Math.min(adjustedFront, adjustedBack));
        
        // Find closest person for risk calculation
        double minDistance = Math.min(Math.min(leftDist, rightDist), Math.min(frontDist, backDist));
        
        // Check if distances meet safety requirements
        boolean isSafe = checkSafeDistance(leftDist, rightDist, frontDist, backDist);
        
        if (isSafe) {
            System.out.println("\nYou are safe in dynamic distancing!");
            activeRobot.setContactStatus("Safe Distance");
            emergencyMode = false; // Reset emergency mode because now the environment is safe
        } else {
            System.out.println("\nSocial distancing warning!");
            provideMoveAdvice(leftDist, rightDist, frontDist, backDist);
            activeRobot.setContactStatus("Casual Contact");
        }
        
        // Update spot occupancy count
        selectedSpot.setCurrentOccupancy(selectedSpot.getCurrentOccupancy() + 1);
        
        // Calculate and display crowd information
        String crowdingLevel = calculateCrowdingLevel(
            selectedSpot.getCurrentOccupancy(), 
            selectedSpot.getSpotMaximumCapacity()
        );
        
        System.out.println("\nCurrent crowding level: " + crowdingLevel);
        if (adjustedLeft < safeThreshold || adjustedRight < safeThreshold || adjustedFront < safeThreshold || adjustedBack < safeThreshold) {
            // unsafe after balancing move
            checkEmergencyConditions(crowdingLevel, minAdjustedDistance);
        }
        
        
        // Suggest best path based on crowding
        String recommendedPath = recommendServingPath(crowdingLevel);
        System.out.println("Recommended serving path: " + recommendedPath);
        
        // Estimate collision risk percentage
        double collisionRisk = estimateCollisionRisk(crowdingLevel, minDistance);
        System.out.println("Estimated collision risk: " + String.format("%.1f", collisionRisk) + "%");
        
        // Show current robot status
        System.out.println("\n=== Robot Status ===");
        System.out.println("Robot ID: " + activeRobot.getRobotId());
        System.out.println("Robot Name: " + activeRobot.getRobotName());
        System.out.println("Spot ID: " + selectedSpot.getSpotId());
        System.out.println("Spot Name: " + selectedSpot.getSpotName());
        System.out.println("Date: " + currentDateTime.toLocalDate());
        System.out.println("Time: " + currentDateTime.toLocalTime());
        System.out.println("Contact Status: " + activeRobot.getContactStatus());
        
        // Deduct battery for movement
        activeRobot.consumeBattery(5);
        
        // Check for VIP customers if in VIP mode
        if (isVipMode) {
            serveVipCustomers();
        }
        
        // Show drink serving options
        serveDrinksMenu();
    }
    
    /**
     * Provides menu for serving drinks and tracking service quality
     */
    private void serveDrinksMenu() {
        if (emergencyMode) {
            System.out.println("\n🚫 Cannot serve drinks during Emergency Evacuation Mode!");
            return;
        }        

        System.out.println("\n=== Serve Drinks Menu ===");
        System.out.println("1. Serve regular drinks");
        System.out.println("2. Serve specialty drinks");
        System.out.println("3. Display serving statistics");
        System.out.println("4. Return to main menu");
        System.out.print("Enter your choice (1-4): ");
        
        int choice = getUserChoice(1, 4);
        
        switch (choice) {
            case 1:
                // Handle regular drink serving
                if (activeRobot.getCurrentDrinks() == 0) {
                    System.out.println("\nERROR: Robot is out of regular drinks! Please refill before serving.");
                    break;
                }
                
                System.out.print("How many regular drinks to serve? ");
                int regularDrinks = getUserChoice(0, activeRobot.getCurrentDrinks());
                
                for (int i = 0; i < regularDrinks; i++) {
                    if (currentMap != null) {
                        // Implement a more dynamic movement pattern
                        int currentX = currentMap.getRobotX();
                        int currentY = currentMap.getRobotY();
                        
                        // Try to move in a pattern: right, down, left, up
                        boolean moved = false;
                        
                        // First try to move right if possible
                        if (currentX < currentMap.getGridWidth() - 1) {
                            moved = currentMap.moveRobot("right");
                        }
                        
                        // If can't move right, try down
                        if (!moved && currentY < currentMap.getGridHeight() - 1) {
                            moved = currentMap.moveRobot("down");
                        }
                        
                        // If can't move down, try left
                        if (!moved && currentX > 0) {
                            moved = currentMap.moveRobot("left");
                        }
                        
                        // If can't move left, try up
                        if (!moved && currentY > 0) {
                            moved = currentMap.moveRobot("up");
                        }
                        
                        if (!moved) {
                            System.out.println("Warning: Robot cannot move - all paths are blocked!");
                        }
                    }

                    if (!activeRobot.serveDrink()) {
                        System.out.println("Failed to serve drink - operation cancelled.");
                        break;
                    }
                    
                    activeRobot.consumeBattery(1); // Each drink uses some battery
                    
                    System.out.println("\nServing regular drink " + (i+1) + "...");
                    System.out.println("Monitoring weight changes...");
                    
                    // Use automatic weight detection for regular drinks
                    boolean success = serviceMonitor.detectSuccessfulServing(true);
                    System.out.println("Drink serving " + (success ? "SUCCESSFUL!" : "FAILED!"));
                    
                    if (!success) {
                        System.out.println("Attempting to serve again...");
                    }
                }
                break;
                
            case 2:
                // Handle specialty drinks (more battery intensive)
                if (activeRobot.getSpecialtyDrinks() == 0) {
                    System.out.println("\nERROR: Robot is out of specialty drinks! Please refill before serving.");
                    break;
                }
                
                System.out.print("How many specialty drinks to serve? ");
                int specialtyDrinks = getUserChoice(0, activeRobot.getSpecialtyDrinks());
                
                for (int i = 0; i < specialtyDrinks; i++) {
                    if (currentMap != null) {
                        // Implement a more dynamic movement pattern
                        int currentX = currentMap.getRobotX();
                        int currentY = currentMap.getRobotY();
                        
                        // Try to move in a pattern: right, down, left, up
                        boolean moved = false;
                        
                        // First try to move right if possible
                        if (currentX < currentMap.getGridWidth() - 1) {
                            moved = currentMap.moveRobot("right");
                        }
                        
                        // If can't move right, try down
                        if (!moved && currentY < currentMap.getGridHeight() - 1) {
                            moved = currentMap.moveRobot("down");
                        }
                        
                        // If can't move down, try left
                        if (!moved && currentX > 0) {
                            moved = currentMap.moveRobot("left");
                        }
                        
                        // If can't move left, try up
                        if (!moved && currentY > 0) {
                            moved = currentMap.moveRobot("up");
                        }
                        
                        if (!moved) {
                            System.out.println("Warning: Robot cannot move - all paths are blocked!");
                        }
                    }

                    activeRobot.serveSpecialtyDrink();
                    activeRobot.consumeBattery(2); // Specialty drinks use more power
                    
                    System.out.println("\nServing specialty drink " + (i+1) + "...");
                    System.out.println("Monitoring weight changes...");
                    
                    // Use automatic weight detection for specialty drinks
                    boolean success = serviceMonitor.detectSuccessfulServing(false);
                    System.out.println("Specialty drink serving " + (success ? "SUCCESSFUL!" : "FAILED!"));
                    
                    if (!success) {
                        System.out.println("Attempting to serve again...");
                    }
                }
                break;
                
            case 3:
                // Show service quality statistics
                serviceMonitor.displayServiceStatistics();
                break;
                
            case 4:
                // Return to main menu
                break;
        }

        if (currentMap != null) {
            // Return to start position after serving
            currentMap.returnToStart();
        }
    }
    
    /**
     * Checks if social distancing is maintained in all directions
     * @param leftDist - Distance to left side in meters
     * @param rightDist - Distance to right side in meters
     * @param frontDist - Distance to front in meters
     * @param backDist - Distance to back in meters
     * @return True if all distances meet safe threshold
     */
    public boolean checkSafeDistance(double leftDist, double rightDist, double frontDist, double backDist) {
        // Social distancing threshold in meters
        double safeThreshold = 1.0;
        
        return leftDist >= safeThreshold && 
               rightDist >= safeThreshold && 
               frontDist >= safeThreshold && 
               backDist >= safeThreshold;
    }
    
    /**
     * Provides movement advice based on unsafe distances
     * @param leftDist - Distance to left side in meters
     * @param rightDist - Distance to right side in meters
     * @param frontDist - Distance to front in meters
     * @param backDist - Distance to back in meters
     */
    public void provideMoveAdvice(double leftDist, double rightDist, double frontDist, double backDist) {
        double safeThreshold = 1.0; // Social distancing minimum (can adjust)
    
        System.out.println("Suggested adjustments to maintain safe distances:");
    
        // Check left and right side together
        double totalHorizontal = leftDist + rightDist;
        double targetHorizontal = totalHorizontal / 2.0;
    
        if (leftDist < safeThreshold || rightDist < safeThreshold) {
            if (leftDist < targetHorizontal) {
                double moveRight = targetHorizontal - leftDist;
                System.out.println("- Move right by " + String.format("%.2f", moveRight) + " meters to balance left and right side.");
            } else if (rightDist < targetHorizontal) {
                double moveLeft = targetHorizontal - rightDist;
                System.out.println("- Move left by " + String.format("%.2f", moveLeft) + " meters to balance left and right side.");
            }
        }
    
        // Check front and back side together
        double totalVertical = frontDist + backDist;
        double targetVertical = totalVertical / 2.0;
    
        if (frontDist < safeThreshold || backDist < safeThreshold) {
            if (frontDist < targetVertical) {
                double moveBack = targetVertical - frontDist;
                System.out.println("- Move back by " + String.format("%.2f", moveBack) + " meters to balance front and back side.");
            } else if (backDist < targetVertical) {
                double moveForward = targetVertical - backDist;
                System.out.println("- Move forward by " + String.format("%.2f", moveForward) + " meters to balance front and back side.");
            }
        }
    }
    
    /**
     * Determines crowding level based on occupancy percentage
     * @param currentOccupancy - Current number of people in area
     * @param maxCapacity - Maximum capacity of the area
     * @return String describing crowding level
     */
    public String calculateCrowdingLevel(int currentOccupancy, int maxCapacity) {
        double occupancyPercentage = (double) currentOccupancy / maxCapacity * 100;
        
        if (occupancyPercentage < 30) {
            return "Low";
        } else if (occupancyPercentage < 60) {
            return "Moderate";
        } else if (occupancyPercentage < 90) {
            return "High";
        } else {
            return "Critical";
        }
    }
    
    /**
     * Suggests optimal movement path based on crowding conditions
     * @param crowdingLevel - Current crowding level string
     * @return String with path recommendation
     */
    public String recommendServingPath(String crowdingLevel) {
        switch (crowdingLevel) {
            case "Low":
                return "Direct path - minimal obstacle avoidance needed";
            case "Moderate":
                return "Zigzag path - take wider turns around tables";
            case "High":
                return "Perimeter path - stay near walls when possible";
            case "Critical":
                return "Staged approach - wait for clearance between movements";
            default:
                return "Standard path";
        }
    }

    /**
     * Checks for emergency evacuation conditions.
     * If crowding is Critical or minimum distance is unsafe, trigger emergency mode.
     */
    private void checkEmergencyConditions(String crowdingLevel, double minDistance) {
        if (crowdingLevel.equals("Critical") || minDistance < 1.0) {
            System.out.println("\n🚨 EMERGENCY! Unsafe conditions detected!");
            System.out.println("All robot operations are temporarily suspended for safety.");
            emergencyMode = true;
        }
    }

    /**
     * Calculates collision risk based on crowding and distance
     * @param crowdingLevel - Current crowding level string
     * @param minDistance - Minimum distance to nearest person
     * @return Risk percentage (0-100)
     */
    public double estimateCollisionRisk(String crowdingLevel, double minDistance) {
        double baseRisk;
        
        // Base risk by crowding level
        switch (crowdingLevel) {
            case "Low":
                baseRisk = 5.0;
                break;
            case "Moderate":
                baseRisk = 15.0;
                break;
            case "High":
                baseRisk = 30.0;
                break;
            case "Critical":
                baseRisk = 50.0;
                break;
            default:
                baseRisk = 10.0;
        }
        
        // Adjust for minimum distance - closer means higher risk
        double distanceFactor;
        if (minDistance < 0.5) {
            distanceFactor = 2.0; // Double risk when very close
        } else if (minDistance < 1.0) {
            distanceFactor = 1.5; // 1.5x risk when somewhat close
        } else if (minDistance < 1.5) {
            distanceFactor = 1.0; // Normal risk
        } else {
            distanceFactor = 0.8; // Reduced risk when far
        }
        
        // Calculate final risk (capped at 100%)
        double riskPercentage = baseRisk * distanceFactor;
        return Math.min(riskPercentage, 100.0);
    }
    
    /**
     * Displays information about all dining spots in the restaurant
     */
    private void displayAllSpots() {
        System.out.println("\n=== All Spots Information ===");
        for (RestrictedSpots spot : spots) {
            spot.displaySpotInfo();
            System.out.println();
        }
    }

    /**
     * Toggles VIP mode for priority service
     */
    private void toggleVipMode() {
        isVipMode = !isVipMode;
        System.out.println("VIP Mode is now " + (isVipMode ? "ACTIVE" : "INACTIVE"));
        
        if (isVipMode) {
            System.out.println("VIP customers will receive priority service.");
            System.out.println("Current VIP customers:");
            for (String vip : vipCustomers) {
                System.out.println("- " + vip);
            }
        }
    }

    /**
     * Provides special service for VIP customers
     */
    private void serveVipCustomers() {
        System.out.println("\n=== VIP Service Mode ===");
        System.out.println("Checking for VIP customers...");
        
        // Simulate finding VIP customers
        boolean vipFound = Math.random() > 0.5;
        
        if (vipFound) {
            int vipIndex = (int) (Math.random() * vipCustomers.length);
            String vipName = vipCustomers[vipIndex];
            
            System.out.println("VIP customer found: " + vipName);
            System.out.println("Providing priority service...");
            
            // Serve VIP customer with a specialty drink if available
            if (activeRobot.getSpecialtyDrinks() > 0) {
                activeRobot.serveSpecialtyDrink();
                System.out.println("VIP customer served with a specialty drink!");
            } 
            // If no specialty drinks, try regular drink
            else if (activeRobot.getCurrentDrinks() > 0) {
                activeRobot.serveDrink();
                System.out.println("VIP customer served with a regular drink!");
            } 
            else {
                System.out.println("Cannot serve VIP customer - no drinks left!");
            }
        } else {
            System.out.println("No VIP customers found in this area.");
        }
    }

    /**
     * Handles drink inventory management
     */
    private void manageDrinks() {
        System.out.println("\n=== Drink Management ===");
        System.out.println("Regular drinks: " + activeRobot.getCurrentDrinks());
        System.out.println("Specialty drinks: " + activeRobot.getSpecialtyDrinks());
        System.out.println("1. Serve a regular drink");
        System.out.println("2. Serve a specialty drink");
        System.out.println("3. Refill regular drinks");
        System.out.println("4. Refill specialty drinks");
        System.out.println("5. Back to main menu");
        System.out.print("Enter your choice (1-5): ");
        
        int choice = getUserChoice(1, 5);
        
        switch (choice) {
            case 1:
                activeRobot.serveDrink();
                activeRobot.consumeBattery(1);
                break;
            case 2:
                activeRobot.serveSpecialtyDrink();
                activeRobot.consumeBattery(2);
                break;
            case 3:
                activeRobot.refillDrinks();
                activeRobot.consumeBattery(3);
                break;
            case 4:
                activeRobot.refillSpecialtyDrinks();
                activeRobot.consumeBattery(3);
                break;
            case 5:
                // Just return to main menu
                break;
        }
    }

    /**
     * Handles robot battery management
     */
    private void manageBattery() {
        System.out.println("\n=== Battery Management ===");
        System.out.println("Current battery level: " + activeRobot.getBatteryLevel() + "%");
        
        if (activeRobot.getBatteryLevel() < 20) {
            System.out.println("WARNING: Low battery level!");
        }
        
        System.out.println("1. Recharge battery");
        System.out.println("2. Back to main menu");
        System.out.print("Enter your choice (1-2): ");
        
        int choice = getUserChoice(1, 2);
        
        if (choice == 1) {
            activeRobot.rechargeBattery();
        }
    }
    
    /**
     * Starts the drink serving system
     */
    public static void main(String[] args) {
        StaticDrinkServing system = new StaticDrinkServing();
        system.runSystem();
    }
}