/**
 * Tracks information about different dining areas in the restaurant.
 * We created this class after sketching out how the restaurant spaces would work on paper.
 * Each spot has its own rules for capacity and social distancing.
 */
class RestrictedSpots {
    // Unique identifier for each dining area (like "S001" for the main hall)
    private String spotId;
    // Human-readable name (like "Family Dining Room")
    private String spotName;
    // Total size in square meters - measured from the restaurant floor plans
    private double spotArea;
    // How long robots typically wait here during busy times (in minutes)
    private int spotPermittedAverageTime;
    // Max people allowed while maintaining social distance
    private int spotMaximumCapacity;
    // Current number of people in this area
    private int currentOccupancy;
    // Available space that's not blocked by furniture (changes during events)
    private double availableSpace;

    /**
     * Sets up a new dining area with its basic properties.
     * The capacity calculation took some trial and error to get right.
     * @param spotId - Short code like "S001"
     * @param spotName - Full name like "VIP Lounge"
     * @param spotArea - Total size in square meters
     * @param spotPermittedAverageTime - Typical wait time during rush hour
     */
    public RestrictedSpots(String spotId, String spotName, double spotArea, int spotPermittedAverageTime) {
        this.spotId = spotId;
        this.spotName = spotName;
        this.spotArea = spotArea;
        this.spotPermittedAverageTime = spotPermittedAverageTime;
        
        // Health regulations require 4m² per person (2x2m personal space)
        this.spotMaximumCapacity = (int) (spotArea / 4);
        
        // Start with random people to simulate real conditions
        // Added +1 because random can return 0 but not the upper bound
        this.currentOccupancy = (int) (Math.random() * (spotMaximumCapacity + 1));
        this.availableSpace = spotArea;
    }

    // Basic getters below - nothing fancy here
    public String getSpotId() { return spotId; }
    public String getSpotName() { return spotName; }
    public double getSpotArea() { return spotArea; }
    public int getSpotPermittedAverageTime() { return spotPermittedAverageTime; }
    public int getSpotMaximumCapacity() { return spotMaximumCapacity; }
    public int getCurrentOccupancy() { return currentOccupancy; }

    /**
     * Updates the current headcount.
     * We check this whenever robots enter/leave.
     * @param currentOccupancy - Must be between 0 and maximum capacity
     */
    public void setCurrentOccupancy(int currentOccupancy) {
        this.currentOccupancy = currentOccupancy;
    }

    /**
     * Tracks available space that's not blocked.
     * During events, some areas might have temporary setups.
     * Updating this automatically adjusts the maximum capacity.
     */
    public double getAvailableSpace() { return availableSpace; }
    public void setAvailableSpace(double availableSpace) {
        this.availableSpace = availableSpace;
        // Recalculate capacity when space changes
        this.spotMaximumCapacity = (int) (availableSpace / 4);
    }

    /**
     * Simple check if we've hit capacity.
     * Used by robots before entering an area.
     * @return true if no more people should enter
     */
    public boolean isFull() {
        return currentOccupancy >= spotMaximumCapacity;
    }

    /**
     * Shows all details about this dining area.
     * Formatted for easy reading by staff.
     * I organized this to show most important info first.
     */
    public void displaySpotInfo() {
        System.out.println("Spot ID: " + spotId);
        System.out.println("Spot Name: " + spotName);
        System.out.println("Spot Area: " + spotArea + " square meters");
        System.out.println("Available Space: " + availableSpace + " square meters");
        System.out.println("Average Waiting Time: " + spotPermittedAverageTime + " minutes");
        System.out.println("Maximum Capacity: " + spotMaximumCapacity + " people");
        System.out.println("Current Occupancy: " + currentOccupancy + " people");
    }
}