// RobotBatteryController.java
public class RobotBatteryController {
    private int batteryLevel; // Battery level in percentage (%)
    private static final int LOW_BATTERY_WARNING = 20; // Warning threshold
    private static final int CRITICAL_BATTERY_LEVEL = 10; // Auto recharge threshold

    public RobotBatteryController(int initialBatteryLevel) {
        this.batteryLevel = initialBatteryLevel;
    }

    // Getter for battery level
    public int getBatteryLevel() {
        return batteryLevel;
    }

    // Setter for battery level
    public void setBatteryLevel(int batteryLevel) {
        this.batteryLevel = Math.max(0, Math.min(batteryLevel, 100)); // Always keep within 0-100%
    }

    // Method to check battery status before moving
    public boolean checkBeforeMove() {
        System.out.println("[Battery Check] Current battery level: " + batteryLevel + "%");

        if (batteryLevel < CRITICAL_BATTERY_LEVEL) {
            System.out.println("[ALERT] Battery critically low! Automatically starting recharge...");
            rechargeBattery();
            return false; // Cannot move yet
        } else if (batteryLevel < LOW_BATTERY_WARNING) {
            System.out.println("[WARNING] Battery low. Please recharge soon.");
        }
        return true; // OK to move
    }

    // Simulate moving: it consumes some battery
    public void moveRobot() {
        if (checkBeforeMove()) {
            System.out.println("Moving to destination...");
            consumeBattery(5); // Example: Moving consumes 5% battery
        } else {
            System.out.println("Movement aborted due to low battery.");
        }
    }

    // Simulate battery consumption
    public void consumeBattery(int consumption) {
        setBatteryLevel(batteryLevel - consumption);
        System.out.println("[Battery Update] Battery after movement: " + batteryLevel + "%");

        if (batteryLevel <= CRITICAL_BATTERY_LEVEL) {
            System.out.println("[ALERT] Battery critically low! Automatically starting recharge...");
            rechargeBattery();
        } else if (batteryLevel <= LOW_BATTERY_WARNING) {
            System.out.println("[WARNING] Battery low. Please recharge soon.");
        }
    }

    // Recharge the battery to full
    public void rechargeBattery() {
        System.out.println("Recharging...");
        batteryLevel = 100;
        System.out.println("[Recharge Complete] Battery fully recharged to 100%!");
    }
}
